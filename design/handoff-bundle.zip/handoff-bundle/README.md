# Plantalog redesign: handoff bundle

Everything needed to implement the redesign, and nothing else.

| Path | What it is |
| --- | --- |
| `Plantalog handoff.md` | The build spec. Type, colour, motion, components, and a change list against the current app. Read first. |
| `Plantalog spec addendum.md` | Twenty rounds of measured comparisons between the design and the build, with every divergence, its cause and its fix. Read second, and treat it as the tiebreaker: where it and the handoff disagree, the addendum is later and wins. |
| `screens/` | 55 standalone screen extracts, named by the ids the two documents cite (`24b`, `13c`, `util-10a`, …). Open them in a browser; they are the design, at real size, in light and dark. |
| `reference-build.html` | **The redesign itself**, self-contained and complete: every fix in the addendum is applied here. Not a mock-up of the work; the result of it. When a value is ambiguous in words, measure this. |
| `app-before/` | The app as it was *before* any of this started: DM Sans, 480px, the old `--leaf` palette. Kept for diffing and for history. **Not a target to build into.** |
| `_ds/` | The Organic design system's stylesheet, which every extract links. **It must travel with `screens/`.** It carries `body{font-size:15px;line-height:1.55}` and the `@import` for Caprasimo and Figtree, so if it fails to load the extracts silently lose §17's line-height *and* both typefaces, and anything measured against them is wrong by about 25% on text blocks and a pixel on controls. |
| `assets/` | The logo mark, cream and green. |

## Read this before you touch anything

**The redesign is already implemented.** `reference-build.html` is it: geometry, tokens and motion match the extracts in both modes, across twenty measured rounds. Supabase wiring, photo handling and PDF export are intact inside it.

An earlier draft of this file said to port the reference into `app/plantalog.jsx`. That was wrong and it has been removed. `app-before/` is the *pre*-redesign app; building the redesign into it again would discard roughly two hundred verified fixes. Do not do that.

**What may genuinely remain** is a packaging step, not a design or styling one. The redesign lives here as a single self-contained file: fonts inlined, JSX already transpiled to `React.createElement`. A deployment of this app is `index.html` plus a `plantalog.jsx` that Babel compiles in the browser. So unless the redesign already exists in that shape somewhere, someone has to put it back into it: the source as `.jsx`, and an `index.html` that links Caprasimo and Figtree instead of DM Sans. Nothing about the design changes in that step, and the addendum's numbers are the check that nothing drifted.

**Measuring an extract: check the stylesheet loaded before you trust a number.** `document.fonts.status` should be `"loaded"` and `getComputedStyle(document.body).lineHeight` should be `23.25px`. If it reads `normal`, `_ds/` isn't resolving and every measurement from that page is invalid. Do not "fix" it by adding a line-height to the extract's own `<style>`; that hides the broken link behind a plausible number and leaves the other tokens missing.

Before starting, confirm which shape the live app is in. A heading in Caprasimo, the chunky rounded display face, and a 390px frame means the redesign has shipped. Plain sans headings at 480px means it has not.

## If the packaging step is needed

Work from `reference-build.html` outward, not from `app-before/` forward. Extract its source, keep every value, and change only what the file format demands. Diff against `app-before/plantalog.jsx` to confirm the plumbing survived, never to reintroduce its styling.

The addendum's `§17` is the one thing to internalise first: the design sets `body{line-height:1.55}` and the old app set nothing, which made roughly every text block render about 25% short. Nearly every "this looks wrong and I can't say why" in the first sixteen rounds traced to that single line. If it goes missing in a port, everything looks subtly wrong again at once.

## Pinned, not in scope

Small-phone widths. At 320px the Edit Room dialog's 7-across colour grid gets tight (24px columns against 26px swatches). Nobody has looked at it and nobody needs to yet; revisit if narrow devices become a concern.

Otherwise nothing is open. §20.4 was the last design decision and it is made and applied; §21 records the measurement-rig corrections that came after it, and closes clean.

One habit from §21 is worth carrying into any further work: **a difference in a declaration is not a difference in the render.** Three separate token mismatches between Organic and the app looked like defects and were not. Confirm an element actually resolves to the wrong value before you change a rule, and prefer per-element fixes to global ones.
